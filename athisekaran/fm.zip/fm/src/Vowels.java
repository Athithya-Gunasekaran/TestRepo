import java.util.Scanner;


public class Vowels {

	public static void main(String[] args) {
Scanner userInput=new Scanner(System.in);
System.out.println("Enter an Alphabet :");

char c = 'e';
char a;
char e;
char i;
char o;
char u;



if(c!='a' || c!='e' || c!='i' || c!='o' || c!='u'){
	System.out.println("The entered alphabet is an Consonant " );
	}
else{
	System.out.println("The entered alphabet is an Vowel ");
	
	
}
	

	
	}

}
