package com.floify.los.automation.regression.suite;

import java.time.Instant;

import com.github.javafaker.Faker;

public class NameGenerator {

	public static void main(String[] args)
	{
//		Faker faker = new Faker();
//		String emailId = "test";
//		for(int i=1;i<=10;i++)
//		{
//			String firstName = faker.name().firstName(); // Emory
//			String lastName = faker.name().lastName(); // Barton
//			
//			System.out.println(emailId + i + "," +firstName + "," + lastName+","+emailId+"+"+i+"@gmail.com");
//		}
		
		Instant start = Instant.now();
		System.out.println(start);
	}
}
